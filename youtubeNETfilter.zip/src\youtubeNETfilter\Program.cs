using System;
using System.Threading.Tasks;

namespace youtubeNETfilter
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("==========================================");
            Console.WriteLine("     youtubeNETfilter v1.0.0 Initialized  ");
            Console.WriteLine("==========================================");

            var filterService = new YoutubeFilterService();
            
            Console.WriteLine("\n[+] Initializing YouTube Data API Filter Engine...");
            var results = await filterService.SearchAndFilterAsync("c# programming tutorials", minDurationMinutes: 10);

            Console.WriteLine($"\n[✓] Found {results.Count} filtered video results:\n");
            foreach (var video in results)
            {
                Console.WriteLine($"• Title: {video.Title}");
                Console.WriteLine($"  Channel: {video.ChannelTitle} | Duration: {video.DurationMinutes} mins | Views: {video.ViewCount:N0}");
                Console.WriteLine($"  URL: https://www.youtube.com/watch?v={video.VideoId}");
                Console.WriteLine(new string('-', 50));
            }

            Console.WriteLine("\nProcess completed successfully.");
        }
    }
}
