using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace youtubeNETfilter
{
    public class VideoItem
    {
        public string VideoId { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string ChannelTitle { get; set; } = string.Empty;
        public int DurationMinutes { get; set; }
        public long ViewCount { get; set; }
    }

    public class YoutubeFilterService
    {
        public async Task<List<VideoItem>> SearchAndFilterAsync(string query, int minDurationMinutes = 0)
        {
            await Task.Delay(500); 

            var mockData = new List<VideoItem>
            {
                new VideoItem { VideoId = "dQw4w9WgXcQ", Title = "C# Full Course for Beginners", ChannelTitle = "DevMaster", DurationMinutes = 45, ViewCount = 1250000 },
                new VideoItem { VideoId = "3JZ_D3ELwOQ", Title = "Short C# Tip", ChannelTitle = "CodeBytes", DurationMinutes = 3, ViewCount = 15000 },
                new VideoItem { VideoId = "L_LUpnjgPso", Title = "Advanced .NET Filter Techniques", ChannelTitle = "DotNetPro", DurationMinutes = 25, ViewCount = 89000 }
            };

            return mockData.Where(v => v.DurationMinutes >= minDurationMinutes).ToList();
        }
    }
}
